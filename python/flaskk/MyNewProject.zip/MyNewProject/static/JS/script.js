const data = [
    {
        imgURL : "./images/book1",
        bookName : "It Ends with Us",
        Author : "Collen Hoover",
        Price : "Rs274"
    },
    {
        imgURL : "./images/book2",
        bookName : "Times Table",
        Author : "Pegasus Team",
        Price : "Rs274"
    },
    {
        imgURL : "./images/book3",
        bookName : "Automic Habits",
        Author : "James Clear",
        Price : "Rs274"
    },
    {        imgURL : "./images/book4",
        bookName : "It Start with Us",
        Author : "Collen Hoover",
        Price : "Rs274"
    }
]