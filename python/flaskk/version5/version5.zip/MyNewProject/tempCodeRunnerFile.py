 except:
    #         return "<script LANGUAGE='JavaScript'>window.alert('ID Already Exit');window.location.href='/home';</script>"
    # except KeyError:
    #     return "<script LANGUAGE='JavaScript'>window.alert('Session Timeout');window.location.href='/';</script>"