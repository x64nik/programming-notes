
from flask import Flask,render_template ,request,redirect
from flask_sqlalchemy import SQLAlchemy
import hash_creds


app = Flask(__name__, template_folder="templates")
  
app.debug = True
 
app.config['SQLALCHEMY_DATABASE_URI'] = 'oracle+cx_oracle://hr:hr@192.168.100.225:1521/xe'

db = SQLAlchemy(app)

# Models
class Book(db.Model):
    
    BOOK_ID = db.Column(db.Integer(), primary_key=True)
    BOOK_NAME = db.Column(db.String(20), unique=False, nullable=False)
    BOOK_AUTHOR = db.Column(db.String(20), unique=False, nullable=False)
    BOOK_PRICE = db.Column(db.Integer())
    
    # represent object of database table
    def __repr__(self):
       pass
    
@app.route('/')
def login():
    return render_template("login.html")


# SIGNUP FORM
@app.route('/success', methods = ['GET', 'POST'])
def signup():
    if request.method == "POST":
        # open creds file to check and insert 
        creds_file = open("creds.txt", "r")
        creds_data = creds_file.read()
    
        uname = request.form.get('uname')
        email = request.form.get('email')
        passwd = request.form.get('passwd')
        
        # hashed creds
        hashed_data = hash_creds.hash(email, passwd)

        if hashed_data in creds_data:
            print("user already exists")
            creds_file.close()
        else:
            creds_file = open("creds.txt", "a")
            creds_file.write(hashed_data + "\n")
            creds_file.close()
        return render_template("index.html")


# LOGIN FORM
@app.route('/books', methods = ['GET','POST'])
def index():
    if request.method == "POST":
        email = request.form.get('email')
        passwd = request.form.get('passwd')
        hashed_data = hash_creds.hash(email, passwd)

        creds_file = open("creds.txt", "r")
        creds_data = creds_file.readlines()

        if hashed_data + "\n" in creds_data:
            return render_template("index.html")
        else:
            return render_template("login.html")


    #     if hashed_data in creds_data:
    #         return render_template("index.html")
    # else:
    #     print("invalid user")


@app.route("/add", methods = ['GET','POST'])
def stuInfo():
    if request.method == "POST":
        bookId = int(request.form.get('bookId'))
        bookName = request.form.get('bookName')
        bookAuthor = request.form.get('bookAuthor')
        bookPrice = int(request.form.get('bookPrice'))
        
        entry = Book(BOOK_ID = bookId, BOOK_NAME = bookName, BOOK_AUTHOR=bookAuthor, BOOK_PRICE = bookPrice )
        
        db.session.add(entry)
        db.session.commit()   
        
    Books = Book.query.all()
    
    return render_template("index.html", Books = Books)
    


@app.route('/delete',methods=["POST","GET"])
def erase():
    BOOK_ID = request.form.get('bookId')
    try:
        data = Book.query.get(BOOK_ID)
  
    except:
        return "You Enterd wrong Id."
      
    db.session.delete(data)
    db.session.commit()
    Books = Book.query.all()
    
    return render_template("index.html", Books = Books)
    
@app.route('/addpage')
def add():
    return render_template("add.html")

@app.route('/deletepage')
def fun():
    return render_template('delete.html')

@app.route('/refresh')
def refresh():
    Books = Book.query.all()
    return render_template("index.html", Books = Books)

if __name__ == "__main__":
    app.run(debug=True)
    