
from flask import Flask, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
import hash_creds


app = Flask(__name__, template_folder="templates")
app.debug = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'oracle+cx_oracle://hr:hr@192.168.100.225:1521/xe'
db = SQLAlchemy(app)

app.secret_key = "test"


# Models
class Book(db.Model):
    
    BOOK_ID = db.Column(db.Integer(), primary_key=True)
    BOOK_NAME = db.Column(db.String(20), unique=False, nullable=False)
    BOOK_AUTHOR = db.Column(db.String(20), unique=False, nullable=False)
    BOOK_PRICE = db.Column(db.Integer())
    
    # represent object of database table
    def __repr__(self):
       pass

@app.route('/login')
def default_login():
    return render_template("login.html")
  
@app.route('/')
def login():
    # print(session['email'])
    creds_file = open("creds.txt", "r")
    creds_data = creds_file.read()
    try:
        if session['email'] in creds_data:
            print(session['email'])
            return render_template("index.html")
        else:
            print("okokokok")
            return redirect("/books")
    except KeyError:
        print("here ------->")
        return redirect("/login")
    finally:
        creds_file.close()


# SIGNUP FORM
@app.route('/success', methods = ['GET', 'POST'])
def signup():
    if request.method == "POST":
        # open creds file to check and insert 
        creds_file = open("creds.txt", "r")
        creds_data = creds_file.read()
    
        uname = request.form.get('uname')
        email = request.form.get('email')
        passwd = request.form.get('passwd')
        
        # hashed creds
        hashed_data = hash_creds.hash(email, passwd)
        try:
            if hashed_data in creds_data:
                return "<script LANGUAGE='JavaScript'>window.alert('User Already Exists!');window.location.href='/';</script>"
                creds_file.close()
            else:
                # print(session['email'])
                session['email'] = hashed_data
                creds_file = open("creds.txt", "a")
                creds_file.write(hashed_data + "\n")
                creds_file.close()
        except KeyError:
            return redirect("/")
        finally:
            creds_file.close()

        return redirect("/")


# LOGIN FORM
@app.route('/books', methods = ['GET','POST'])
def index():
    if request.method == "POST":
        email = request.form.get('email')
        passwd = request.form.get('passwd')
        hashed_data = hash_creds.hash(email, passwd)
        creds_file = open("creds.txt", "r")
        creds_data = creds_file.read()

        try:
            if session['email'] in hashed_data:
                # print(session['email'])
                return render_template("index.html")
            elif hashed_data in creds_data:
                return render_template("index.html")
            else:
                return render_template("login.html")

        except KeyError:
            if hashed_data in creds_data:
                session['email'] = hashed_data
                return render_template("index.html")
        finally:
            creds_file.close()




    return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>"

        # creds_file = open("creds.txt", "r")
        # creds_data = creds_file.readlines()

        # if hashed_data + "\n" in creds_data:
        #     return render_template("index.html")
        # else:
        #     return render_template("login.html")


    #     if hashed_data in creds_data:
    #         return render_template("index.html")
    # else:
    #     print("invalid user")


@app.route("/add", methods = ['GET','POST'])
def stuInfo():
    try: 
        session['email']
        if request.method == "POST":
            bookId = int(request.form.get('bookId'))
            bookName = request.form.get('bookName')
            bookAuthor = request.form.get('bookAuthor')
            bookPrice = int(request.form.get('bookPrice'))

            # print(file)


            entry = Book(BOOK_ID = bookId, BOOK_NAME = bookName, BOOK_AUTHOR=bookAuthor, BOOK_PRICE = bookPrice )
            
            db.session.add(entry)
            db.session.commit()   
            
        Books = Book.query.all()
        
        return render_template("index.html", Books = Books)
    except KeyError:
        return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>" 
        


@app.route('/delete',methods=["POST","GET"])
def erase():
    try:
        session['email']
        BOOK_ID = request.form.get('bookId')
        try:
            data = Book.query.get(BOOK_ID)
      
        except:
            return "You Enterd wrong Id."
    except KeyError:
        return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>"
          
    db.session.delete(data)
    db.session.commit()
    Books = Book.query.all()
    
    return render_template("index.html", Books = Books)
    
@app.route('/addpage')
def add():
    try:
        session['email']
        return render_template("add.html")
    except KeyError:
        return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>"

@app.route('/deletepage')
def fun():
    try:
        session['email']
        return render_template('delete.html')
    except KeyError:
        return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>"
        
@app.route('/refresh')
def refresh():
    try:
        session['email']
        Books = Book.query.all()
        return render_template("index.html", Books = Books)
    except KeyError:
        return "<script LANGUAGE='JavaScript'>window.alert('No Entry');window.location.href='/';</script>"

@app.route('/logout')
def logout():
    creds_file = open("creds.txt", "r")
    creds_data = creds_file.read()
    try:
        if session['email'] in creds_data:
            session.pop('email',None)
            return render_template("login.html")
        else:
            return '<p>user already logged out</p>'
    except KeyError:
        return redirect("/")
    finally:
        creds_file.close()



@app.errorhandler(Exception)
def error0(error):
    return '<p>error</p>'

    

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True)
    