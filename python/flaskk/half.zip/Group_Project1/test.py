

file = open("creds.txt", "r")
data = file.readlines()

if "032d6740962576d9bca45fa2716b409078132dea90d46802a1c59570275cf8ae\n" in  data:
	print(data)

else:
	print("ok")